# ChurchFont Studio
AHSAL Innovations | Faith. Design. Communication.

## Current release
This repository package is a browser-based prototype built with plain HTML, CSS, and JavaScript. It has no build step and no paid API dependency.

## Run locally
Open `index.html` in a modern browser.

## Included in this prototype
- Dashboard and navigation
- Bulletin, flyer, worship program, memorial and newsletter starting templates
- Live editing for church name, title, date, theme, scripture, welcome text, service order, announcements and footer
- Typography and accent color controls
- Save, open, duplicate and delete publications using browser LocalStorage
- Basic page-count controls
- Project JSON export
- Browser print / Save as PDF layout for US Letter

## Important limitations
This is a working first prototype, not a production-ready commercial desktop publishing suite. The page-count control records additional pages but does not yet create a full independent multi-page layout editor. There is no cloud sync, login, team collaboration, drag-and-drop object placement, upload library, email distribution, or print-shop preflight. Those require subsequent implementation and testing.

## Data and privacy
Projects are stored in the browser's LocalStorage on the device/browser where they were created. Export project JSON backups regularly. Clearing browser storage may delete saved projects.

## Brand and legal
ChurchFont is a working product name. Trademark and domain clearance must be independently verified before commercial launch. This package does not provide legal clearance.

## Next engineering milestones
1. Real multi-page document model and page navigation
2. Rich text controls and movable content blocks
3. Image/logo upload and crop
4. Export engine with PDF pagination and embedded font checks
5. Project import and recovery
6. Authentication, cloud persistence and organization workspaces
7. Accessibility, browser compatibility, security and print validation
8. Automated tests and production deployment
